-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2023 at 10:43 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alphonsusschool`
--
CREATE DATABASE IF NOT EXISTS `alphonsusschool` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `alphonsusschool`;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `ClassID` int(10) NOT NULL,
  `ClassName` varchar(100) NOT NULL,
  `Capacity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`ClassID`, `ClassName`, `Capacity`) VALUES
(1, 'Reception Year', 55),
(2, 'Year One', 47),
(3, 'Year Two', 67),
(4, 'Year Three', 45);

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `GuardianID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Telephone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`GuardianID`, `Name`, `Address`, `Email`, `Telephone`) VALUES
(1, 'Mathews', 'London, UK', 'mathews@gmail.com', '9876521'),
(2, 'Richard', 'Edinburg, Scotland', 'pichard@gmail.com', '6872347633');

-- --------------------------------------------------------

--
-- Table structure for table `pupils`
--

CREATE TABLE `pupils` (
  `PupilID` int(10) NOT NULL,
  `PupilName` varchar(50) NOT NULL,
  `PupilAddress` varchar(100) NOT NULL,
  `MedicalInfo` varchar(100) NOT NULL,
  `ClassID` int(10) NOT NULL,
  `GuardianID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pupils`
--

INSERT INTO `pupils` (`PupilID`, `PupilName`, `PupilAddress`, `MedicalInfo`, `ClassID`, `GuardianID`) VALUES
(1, 'Kaya', 'Edinburg, Scotland', 'Nothing', 1, 1),
(2, 'Mandy', 'Edinburg, Scotland', 'Nothing', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `TeacherID` int(10) NOT NULL,
  `TeacherName` varchar(100) NOT NULL,
  `TeacherAddress` varchar(100) NOT NULL,
  `PhoneNumber` varchar(100) NOT NULL,
  `AnnualSalary` decimal(11,0) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `IDNumber` int(11) NOT NULL,
  `BackgroundCheckStatus` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`TeacherID`, `TeacherName`, `TeacherAddress`, `PhoneNumber`, `AnnualSalary`, `Subject`, `IDNumber`, `BackgroundCheckStatus`) VALUES
(1, 'Ethan', 'Brisbane', '12345678', 120000, 'IoT', 1234654, 'yes'),
(2, 'Ethan', 'Brisbane', '12345678', 120000, 'IoT', 1234654, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `teachingplan`
--

CREATE TABLE `teachingplan` (
  `TeacherID` int(10) NOT NULL,
  `ClassID` int(10) NOT NULL,
  `Day` varchar(20) NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`ClassID`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`GuardianID`);

--
-- Indexes for table `pupils`
--
ALTER TABLE `pupils`
  ADD PRIMARY KEY (`PupilID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`TeacherID`);

--
-- Indexes for table `teachingplan`
--
ALTER TABLE `teachingplan`
  ADD PRIMARY KEY (`TeacherID`,`ClassID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `ClassID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `GuardianID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pupils`
--
ALTER TABLE `pupils`
  MODIFY `PupilID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `TeacherID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
