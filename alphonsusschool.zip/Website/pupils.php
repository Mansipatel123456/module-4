<?php
// Database credentials
$servername = "localhost"; // Change this to your database server hostname
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "alphonsusschool";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize a variable for success message
$success_message = "";

// Fetch available Class IDs from the "classes" table
$class_ids = array();
$result = $conn->query("SELECT ClassID FROM classes");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $class_ids[] = $row["ClassID"];
    }
}

// Fetch available Guardian IDs from the "parents" table
$guardian_ids = array();
$result = $conn->query("SELECT GuardianID FROM parents");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $guardian_ids[] = $row["GuardianID"];
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form
    $pupilname = $_POST["pupilname"];
    $address = $_POST["address"];
    $medicalinfo = $_POST["medicalinfo"];
    $classid = $_POST["classid"];
    $guardianid = $_POST["guardianid"];

    // Prepare and execute the SQL query to insert data
    $sql = "INSERT INTO pupils (PupilName, PupilAddress, MedicalInfo, `ClassID`, `GuardianID`) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $pupilname, $address, $medicalinfo, $classid, $guardianid);

    if ($stmt->execute()) {
        $success_message = "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Fetch data from the "pupils" table
$data = array();
$result = $conn->query("SELECT * FROM pupils");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<script>
  function validateForm() {
    var pupilname = document.getElementById("pupilname").value;
    var address = document.getElementById("address").value;
    var medicalinfo = document.getElementById("medicalinfo").value;
    var classid = document.getElementById("classid").value;
    var guardianid = document.getElementById("guardianid").value;

    if (pupilname === "") {
      alert("Pupil name must be filled out");
      return false;
    }

    if (address === "") {
      alert("Address must be filled out");
      return false;
    }

    if (medicalinfo === "") {
      alert("Medical info must be filled out");
      return false;
    }

    if (classid === "") {
      alert("Please select a Class ID");
      return false;
    }

    if (guardianid === "") {
      alert("Please select a Guardian ID");
      return false;
    }
  }
</script>

<body>

<h2>St Alphonsus Primary School</h2>
<p>Welcome to our new web application</p>

<div class="navbar">
  <a href="index.php">Home</a> 
  <a href="classes.php">Classes</a> 
  <a class="active" href="pupils.php">Pupils</a> 
  <a href="teachers.php">Teachers</a>
  <a href="parents.php">Parents</a>
</div>

<div class="container">
  <!-- Display success message if set -->
  <?php if (!empty($success_message)) : ?>
    <div class="success-alert">
      <?php echo $success_message; ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="return validateForm();">
    <label for="pupilname">Name</label>
    <input type="text" id="pupilname" name="pupilname" placeholder="Pupil name..">

    <label for="address">Address</label>
    <input type="text" id="address" name="address" placeholder="Your address..">
	
	<label for="medicalinfo">Medical Info</label>
    <input type="text" id="medicalinfo" name="medicalinfo" placeholder="Your medical info..">
	
	<label for="classid">Class Id</label>
	<select id="classid" name="classid">
      <?php foreach ($class_ids as $class_id) : ?>
        <option value="<?php echo $class_id; ?>"><?php echo $class_id; ?></option>
      <?php endforeach; ?>
    </select>
	
	<label for="guardianid">Guardian Id</label>
	<select id="guardianid" name="guardianid">
      <?php foreach ($guardian_ids as $guardian_id) : ?>
        <option value="<?php echo $guardian_id; ?>"><?php echo $guardian_id; ?></option>
      <?php endforeach; ?>
    </select>
	
    <input type="submit" value="Submit">
  </form>
</div>

<!-- Display data in a table -->
<table>
  <tr>
    <th>Pupil ID</th>
    <th>Name</th>
    <th>Address</th>
    <th>Medical Info</th>
    <th>Class ID</th>
    <th>Guardian ID</th>
  </tr>
  <?php foreach ($data as $row) : ?>
    <tr>
      <td><?php echo $row["PupilID"]; ?></td>
      <td><?php echo $row["PupilName"]; ?></td>
      <td><?php echo $row["PupilAddress"]; ?></td>
      <td><?php echo $row["MedicalInfo"]; ?></td>
      <td><?php echo $row["ClassID"]; ?></td>
      <td><?php echo $row["GuardianID"]; ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<!-- Rest of your HTML content -->

</body>
</html>
