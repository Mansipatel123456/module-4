<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<body>

<h2>St Alphonsus Primary School</h2>
<p>Welcome to our new web application</p>

<div class="navbar">
  <a class="active" href="index.php">Home</a> 
  <a href="classes.php">Classes</a> 
  <a href="pupils.php">Pupils</a> 
  <a href="teachers.php">Teachers</a>
  <a href="parents.php">Parents</a>
</div>

<div class="card-container">
  <div class="card">
    <img src="user.png" alt="Pupils" style="width:100%">
    <h1>Pupils</h1>
    <p class="title">The pupil information, such as name, address, medical information etc is held</p>
    <p>St Alphonsus Primary School</p>
    <p><button onclick="redirectToPupilsPage()">Pupils</button></p>
  </div>
  
  <div class="card">
    <img src="user.png" alt="Classes" style="width:100%">
    <h1>Classes</h1>
    <p class="title">There are 7 classes in total; RYear, Year 1, Year 2, Year 3, Year 4, Year 5 and Year 6</p>
    <p>St Alphonsus Primary School</p>
    <p><button onclick="redirectToClassesPage()">Classes</button></p>
  </div>
  
  <div class="card">
    <img src="user.png" alt="Teachers" style="width:100%">
    <h1>Teachers</h1>
    <p class="title">The teacher information is held, name, address, ph.number, salary etc.</p>
    <p>St Alphonsus Primary School</p>
    <p><button onclick="redirectToTeachersPage()">Teachers</button></p>
  </div>
  
  <div class="card">
    <img src="user.png" alt="Parents" style="width:100%">
    <h1>Parents</h1>
    <p class="title">The parent information is held, such as their name, address, email,
telephone etc.</p>
    <p>St Alphonsus Primary School</p>
    <p><button onclick="redirectToParentsPage()">Parents</button></p>
  </div>
</div>

<script>
function redirectToPupilsPage() {
  window.location.href = "pupils.php";
}

function redirectToClassesPage() {
  window.location.href = "classes.php";
}

function redirectToTeachersPage() {
  window.location.href = "teachers.php";
}

function redirectToParentsPage() {
  window.location.href = "parents.php";
}
</script>
</body>
</html>
