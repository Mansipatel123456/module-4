<?php
// Database credentials
$servername = "localhost"; // Change this to your database server hostname
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "alphonsusschool";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize a variable for success message
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form
    $teachername = $_POST["teachername"];
    $address = $_POST["address"];
    $telephone = $_POST["telephone"];
    $annsalary = $_POST["annsalary"];
    $sub = $_POST["sub"];
    $idproof = $_POST["idproof"];
    $verified = $_POST["verified"];

    // Prepare and execute the SQL query to insert data
    $sql = "INSERT INTO teachers (TeacherName, TeacherAddress, PhoneNumber, AnnualSalary, Subject, IDNumber, BackgroundCheckStatus) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $teachername, $address, $telephone, $annsalary, $sub, $idproof, $verified);

    if ($stmt->execute()) {
        $success_message = "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Fetch data from the "teachers" table
$data = array();
$result = $conn->query("SELECT * FROM teachers");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<script>
  function validateForm() {
    var teachername = document.getElementById("teachername").value;
    var address = document.getElementById("address").value;
    var phonenumber = document.getElementById("phonenumber").value;
    var annualsalary = document.getElementById("annualsalary").value;
    var subject = document.getElementById("subject").value;
    var idnumber = document.getElementById("idnumber").value;
    var backgroundcheckstatus = document.getElementById("backgroundcheckstatus").value;

    if (teachername === "") {
      alert("Teacher name must be filled out");
      return false;
    }

    if (address === "") {
      alert("Address must be filled out");
      return false;
    }

    if (phonenumber === "") {
      alert("Phone number must be filled out");
      return false;
    }

    if (annualsalary === "") {
      alert("Annual salary must be filled out");
      return false;
    }

    if (subject === "") {
      alert("Subject must be filled out");
      return false;
    }

    if (idnumber === "") {
      alert("ID number must be filled out");
      return false;
    }

    if (backgroundcheckstatus === "") {
      alert("Background check status must be filled out");
      return false;
    }
  }
</script>

<body>

<h2>St Alphonsus Primary School</h2>
<p>Welcome to our new web application</p>

<div class="navbar">
  <a href="index.php">Home</a> 
  <a href="classes.php">Classes</a> 
  <a href="pupils.php">Pupils</a> 
  <a class="active" href="teachers.php">Teachers</a>
  <a href="parents.php">Parents</a>
</div>

<div class="container">
  <!-- Display success message if set -->
  <?php if (!empty($success_message)) : ?>
    <div class="success-alert">
      <?php echo $success_message; ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="return validateForm();">
    <label for="teachername">Name</label>
    <input type="text" id="teachername" name="teachername" placeholder="Teacher name..">

    <label for="address">Address</label>
    <input type="text" id="address" name="address" placeholder="Your address..">
	
	<label for="telephone">Telephone</label>
    <input type="text" id="telephone" name="telephone" placeholder="Your telephone..">
	
	<label for="annsalary">Annual Salary</label>
    <input type="text" id="annsalary" name="annsalary" placeholder="Your Annual salary..">
	
	<label for="sub">Subject</label>
    <input type="text" id="sub" name="sub" placeholder="Your Subject..">
	
	<label for="idproof">Indentity proof</label>
    <input type="number" id="idproof" name="idproof" placeholder="Your id proof..">
	
	<label for="verified">Verification status</label>
	<select id="verified" name="verified">
      <option value="yes">Yes</option>
      <option value="no">No</option>
      <option value="hold">Hold</option>
    </select>
	
    <input type="submit" value="Submit">
  </form>
</div>

<!-- Display data in a table -->
<table>
  <tr>
    <th>Teacher ID</th>
    <th>Name</th>
    <th>Address</th>
    <th>Telephone</th>
    <th>Annual Salary</th>
    <th>Subject</th>
    <th>ID Proof</th>
    <th>Verification Status</th>
  </tr>
  <?php foreach ($data as $row) : ?>
    <tr>
      <td><?php echo $row["TeacherID"]; ?></td>
      <td><?php echo $row["TeacherName"]; ?></td>
      <td><?php echo $row["TeacherAddress"]; ?></td>
      <td><?php echo $row["PhoneNumber"]; ?></td>
      <td><?php echo $row["AnnualSalary"]; ?></td>
      <td><?php echo $row["Subject"]; ?></td>
      <td><?php echo $row["IDNumber"]; ?></td>
      <td><?php echo $row["BackgroundCheckStatus"]; ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<!-- Rest of your HTML content -->

</body>
</html>
