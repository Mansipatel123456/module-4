<?php
// Database credentials
$servername = "localhost"; // Change this to your database server hostname
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "alphonsusschool";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize a variable for success message
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form
    $classname = $_POST["classname"];
    $capacity = $_POST["capacity"];

    // Prepare and execute the SQL query to insert data
    $sql = "INSERT INTO classes (classname, capacity) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $classname, $capacity);

    if ($stmt->execute()) {
        $success_message = "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}
// Fetch data from the database
$data = array();
$result = $conn->query("SELECT * FROM classes");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<script>
  function validateForm() {
    var classname = document.getElementById("classname").value;
    var capacity = document.getElementById("capacity").value;

    if (classname === "") {
      alert("Class name must be filled out");
      return false;
    }

    if (capacity === "") {
      alert("Capacity must be filled out");
      return false;
    }
  }
</script>

<body>

<h2>St Alphonsus Primary School</h2>
<p>Welcome to our new web application</p>

<div class="navbar">
  <a href="index.php">Home</a> 
  <a class="active" href="classes.php">Classes</a> 
  <a href="pupils.php">Pupils</a> 
  <a href="teachers.php">Teachers</a>
  <a href="parents.php">Parents</a>
</div>

<div class="container">
  <?php if (!empty($success_message)) : ?>
    <div class="success-alert">
      <?php echo $success_message; ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="return validateForm();">
    <label for="cname">Class Name</label>
    <input type="text" id="cname" name="classname" placeholder="Class name..">

    <label for="capacity">Capacity</label>
    <input type="number" id="capacity" name="capacity" placeholder="Your class capacity..">

    <input type="submit" value="Submit">
  </form>
</div>

<!-- Display data in a table -->
<table>
  <tr>
    <th>Class Id</th>
    <th>Class Name</th>
    <th>Capacity</th>
  </tr>
  <?php foreach ($data as $row) : ?>
    <tr>
      <td><?php echo $row["ClassID"]; ?></td>
      <td><?php echo $row["ClassName"]; ?></td>
      <td><?php echo $row["Capacity"]; ?></td>
    </tr>
  <?php endforeach; ?>
</table>
</body>
</html>
