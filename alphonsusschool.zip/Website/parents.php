<?php
// Database credentials
$servername = "localhost"; // Change this to your database server hostname
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "alphonsusschool";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize a variable for success message
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the form
    $parentname = $_POST["parentname"];
    $address = $_POST["address"];
    $email = $_POST["email"];
    $telephone = $_POST["telephone"];

    // Prepare and execute the SQL query to insert data
    $sql = "INSERT INTO parents (Name, Address, Email, Telephone) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $parentname, $address, $email, $telephone);

    if ($stmt->execute()) {
        $success_message = "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Fetch data from the "parents" table
$data = array();
$result = $conn->query("SELECT * FROM parents");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<script>
  function validateForm() {
    var parentname = document.getElementById("parentname").value;
    var address = document.getElementById("address").value;
    var email = document.getElementById("email").value;
    var telephone = document.getElementById("telephone").value;

    if (parentname === "") {
      alert("Parent name must be filled out");
      return false;
    }

    if (address === "") {
      alert("Address must be filled out");
      return false;
    }

    if (email === "") {
      alert("Email must be filled out");
      return false;
    }

    if (telephone === "") {
      alert("Telephone must be filled out");
      return false;
    }
  }
</script>

<body>

<h2>St Alphonsus Primary School</h2>
<p>Welcome to our new web application</p>

<div class="navbar">
  <a href="index.php">Home</a> 
  <a href="classes.php">Classes</a> 
  <a href="pupils.php">Pupils</a> 
  <a href="teachers.php">Teachers</a>
  <a class="active" href="parents.php">Parents</a>
</div>

<div class="container">
  <!-- Display success message if set -->
  <?php if (!empty($success_message)) : ?>
    <div class="success-alert">
      <?php echo $success_message; ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" onsubmit="return validateForm();">
    <label for="parentname">Name</label>
    <input type="text" id="parentname" name="parentname" placeholder="Parent name..">

    <label for="address">Address</label>
    <input type="text" id="address" name="address" placeholder="Your address..">
	
	<label for="email">Email</label>
    <input type="text" id="email" name="email" placeholder="Your email..">
	
	<label for="telephone">Telephone</label>
    <input type="text" id="telephone" name="telephone" placeholder="Your telephone..">

    <input type="submit" value="Submit">
  </form>
</div>

<!-- Display data in a table -->
<table>
  <tr>
    <th>Guardian ID</th>
    <th>Name</th>
    <th>Address</th>
    <th>Email</th>
    <th>Telephone</th>
  </tr>
  <?php foreach ($data as $row) : ?>
    <tr>
      <td><?php echo $row["GuardianID"]; ?></td>
      <td><?php echo $row["Name"]; ?></td>
      <td><?php echo $row["Address"]; ?></td>
      <td><?php echo $row["Email"]; ?></td>
      <td><?php echo $row["Telephone"]; ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<!-- Rest of your HTML content -->

</body>
</html>
